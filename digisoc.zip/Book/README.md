# Metaverse book

## Purpose

The book folder contains LaTeX files and a PDF file of a book which aims to present the state of the art about Web3, Bitcoin, and ‘Metaverse’; describing the intersections and synergies.